#include "bootloader_common.h"
#include "esp_rom_gpio.h"
#include "soc/gpio_reg.h"
#include "soc/soc.h"
#include "esp_log.h"


/* Function used to tell the linker to include this file
 * with all its symbols.
 */
void bootloader_hooks_include(void){
}

static inline void boot_gpio_output_set(int pin, int level)
{
    esp_rom_gpio_pad_select_gpio(pin);

    REG_WRITE(GPIO_ENABLE_W1TS_REG, BIT(pin));

    if (level) {
        REG_WRITE(GPIO_OUT_W1TS_REG, BIT(pin)); // 拉高
    } else {
        REG_WRITE(GPIO_OUT_W1TC_REG, BIT(pin)); // 拉低（W1TC：write-1-to-clear）
    }
}
void bootloader_before_init(void) {
    boot_gpio_output_set(0, 1); // 举例：GPIO1 拉高
    ESP_LOGI("HOOK", "before init========================================");
}

void bootloader_after_init(void) {
    ESP_LOGI("HOOK", "This hook is called AFTER bootloader initialization");
}